# Task 1: Language Translation Tool

**Student:** Samkelisiwe Beverly Khuzwayo  
**Student ID:** CA/DF1/315315

## Description
A simple web application built with Streamlit. Users enter text, select a source language and a target language, and receive a translation using the Google Translate service through the `deep-translator` Python package.

## Features
- Text input area
- Source-language selection, including automatic language detection
- Target-language selection
- Translation result display
- Basic input validation and error handling

## Requirements
- Python 3.9 or later
- Internet connection
- Packages listed in `requirements.txt`

## Run the project
1. Open a terminal in this folder.
2. Create and activate a virtual environment (recommended).
3. Install dependencies: `pip install -r requirements.txt`
4. Start the app: `streamlit run app.py`
5. Open the local address shown in the terminal (usually `http://localhost:8501`).

## Notes
The translation service requires an internet connection and may be subject to service limits or changes. Review translations before using them for legal, medical, or other important purposes.
