import streamlit as st
from deep_translator import GoogleTranslator
from deep_translator.exceptions import TranslationNotFound

st.set_page_config(page_title="Language Translation Tool", page_icon="🌍")
st.title("🌍 Language Translation Tool")
st.write("Enter text, choose the source and target languages, and translate.")

LANGUAGES = {
    "Auto detect": "auto",
    "English": "en",
    "Zulu": "zu",
    "Afrikaans": "af",
    "Sesotho": "st",
    "French": "fr",
    "Spanish": "es",
    "Portuguese": "pt",
    "German": "de",
    "Chinese (Simplified)": "zh-CN",
    "Japanese": "ja",
    "Arabic": "ar",
    "Hindi": "hi",
}

with st.form("translation_form"):
    source_name = st.selectbox("Source language", list(LANGUAGES.keys()))
    target_options = [name for name in LANGUAGES if name != "Auto detect"]
    target_name = st.selectbox("Target language", target_options, index=target_options.index("Zulu"))
    source_text = st.text_area("Text to translate", height=160, placeholder="Type or paste your text here...")
    submitted = st.form_submit_button("Translate")

if submitted:
    if not source_text.strip():
        st.warning("Please enter some text before translating.")
    elif source_name == target_name:
        st.info("Choose two different languages.")
    else:
        try:
            translator = GoogleTranslator(
                source=LANGUAGES[source_name],
                target=LANGUAGES[target_name]
            )
            translated = translator.translate(source_text.strip())
            st.subheader("Translation")
            st.text_area("Translated text", value=translated or "", height=160)
            if translated:
                st.success("Translation completed.")
        except TranslationNotFound:
            st.error("The translation could not be found. Try shorter text or another language.")
        except Exception as error:
            st.error("Translation failed. Check your internet connection and try again.")
            st.caption(f"Technical detail: {error}")

st.divider()
st.caption("Educational project. Translation quality may vary; review important translations.")
